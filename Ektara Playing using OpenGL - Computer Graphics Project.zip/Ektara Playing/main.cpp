
#include <windows.h>
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <stdlib.h>

#include <stdlib.h>
#include <math.h>


float cld=0.0;
float brd=0.0;
float bt=0.0;
float sn=0.0;

static float	tx	=  0.0;
static float	ty	=  0.0;

int cnt=0;

void circle(GLfloat rx,GLfloat ry,GLfloat cx,GLfloat cy)
{
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx,cy);

    for(int i=0; i<=500; i++)

    {
        float angle = 2.0f * 3.1416f * i/500;

        float x = rx * cosf(angle);
        float y = ry * sinf(angle);

        glVertex2f((x+cx),(y+cy));
    }
    glEnd();
}

void Display()
{
    glClear(GL_COLOR_BUFFER_BIT);

///sky

    glColor3f(0.0,0.9,0.9);
    glBegin(GL_POLYGON);
    glVertex2f(0,570);
    glVertex2f(1100,570);
    glVertex2f(1100,800);
    glVertex2f(0,800);

    glEnd();

///hills

    glColor3f(0.06,0.6,0.3);
    glBegin(GL_POLYGON);
    glVertex2f(0,570);
    glVertex2f(150,570);
    glVertex2f(60,670);
    glVertex2f(0,620);

    glEnd();

    glColor3f(0.06,0.6,0.3);
    glBegin(GL_POLYGON);
    glVertex2f(100,570);
    glVertex2f(250,570);
    glVertex2f(150,685);
    glVertex2f(120,650);

    glEnd();

    glColor3f(0.06,0.6,0.3);
    glBegin(GL_POLYGON);
    glVertex2f(220,570);
    glVertex2f(450,570);
    glVertex2f(300,665);
    glVertex2f(250,650);

    glEnd();

    glColor3f(0.06,0.6,0.3);
    glBegin(GL_POLYGON);
    glVertex2f(600,570);
    glVertex2f(780,570);
    glVertex2f(700,690);
    glVertex2f(659,665);
    glVertex2f(610,590);

    glEnd();

    glColor3f(0.06,0.6,0.3);
    glBegin(GL_POLYGON);
    glVertex2f(750,570);
    glVertex2f(890,570);
    glVertex2f(860,650);
    glVertex2f(835,665);
    glVertex2f(795,590);

    glEnd();

    glColor3f(0.06,0.6,0.3);
    glBegin(GL_POLYGON);
    glVertex2f(870,570);
    glVertex2f(1129,570);
    glVertex2f(1050,635);
    glVertex2f(935,655);
    glVertex2f(895,590);

    glEnd();

///sun

    glColor3f(1.0, 0.9, 0.0);
    circle(45,45,500+sn,740);

///cloud1

    glColor3f(1.0,1.0,1.0);

    circle(30,20,100+cld,705);
    circle(30,20,120+cld,715);
    circle(30,20,130+cld,695);
    circle(35,20,150+cld,704);

///cloud2

    glColor3f(1.0,1.0,1.0);

    circle(30,20,300+cld,700);
    circle(30,20,320+cld,710);
    circle(30,25,330+cld,690);
    circle(30,25,370+cld,700);
    circle(35,20,380+cld,704);

///bird1

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(390+brd,650);
    glVertex2f(410+brd,635);
    glVertex2f(430+brd,630);
    glVertex2f(460+brd,650);
    glEnd();

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(460+brd,650);
    glVertex2f(455+brd,660);
    glVertex2f(450+brd,660);
    glVertex2f(440+brd,650);

    glEnd();

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(410+brd,650);
    glVertex2f(430+brd,650);
    glVertex2f(380+brd,670);


    glEnd();

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(420+brd,650);
    glVertex2f(440+brd,650);
    glVertex2f(410+brd,675);


    glEnd();

///bird2

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(490+brd,650);
    glVertex2f(510+brd,635);
    glVertex2f(530+brd,630);
    glVertex2f(560+brd,650);
    glEnd();

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(560+brd,650);
    glVertex2f(555+brd,660);
    glVertex2f(550+brd,660);
    glVertex2f(540+brd,650);

    glEnd();

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(510+brd,650);
    glVertex2f(530+brd,650);
    glVertex2f(480+brd,670);


    glEnd();

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(520+brd,650);
    glVertex2f(540+brd,650);
    glVertex2f(510+brd,675);


    glEnd();

///bird3

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(460+brd,610);
    glVertex2f(480+brd,595);
    glVertex2f(500+brd,590);
    glVertex2f(530+brd,610);
    glEnd();

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(530+brd,610);
    glVertex2f(525+brd,620);
    glVertex2f(520+brd,620);
    glVertex2f(510+brd,610);

    glEnd();

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(480+brd,610);
    glVertex2f(500+brd,610);
    glVertex2f(450+brd,630);


    glEnd();

    glColor3f(0.5, 0.5, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(490+brd,610);
    glVertex2f(510+brd,610);
    glVertex2f(480+brd,635);


    glEnd();


///water

    glColor3f(0.2,0.55, 1.0);
    glBegin(GL_POLYGON);
    glVertex2f(0,0);
    glVertex2f(1100,0);
    glVertex2f(1100,570);
    glVertex2f(0,570);
    glEnd();



///land

    glColor3f(0.45,0.8, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(0,0);
    glVertex2f(1100,0);
    glVertex2f(1100,120);
    glVertex2f(600,250);

    glVertex2f(400,400);
    glVertex2f(170,500);

    glVertex2f(150,570);
    glVertex2f(0,570);
    glEnd();

///road

    glColor3f(0.5,0.35, 0.0);
    glBegin(GL_POLYGON);

    glVertex2f(0,0);
    glVertex2f(1100,0);
    glVertex2f(1100,40);
    glVertex2f(0,40);

    glEnd();

///boat1 moving

    glColor3f(0.3,0.1, 0.1);
    glBegin(GL_POLYGON);
    glVertex2f(800-bt,490);
    glVertex2f(860-bt,460);
    glVertex2f(1040-bt,460);
    glVertex2f(1090-bt,490);

    glEnd();

    glColor3f(0.8,0.8, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(870-bt,490);
    glVertex2f(1030-bt,490);
    glVertex2f(1020-bt,515);
    glVertex2f(1000-bt,530);
    glVertex2f(900-bt,530);
    glVertex2f(880-bt,520);

    glEnd();

    glColor3f(0.0,0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(920-bt,530);
    glVertex2f(925-bt,530);
    glVertex2f(925-bt,610);
    glVertex2f(920-bt,610);

    glEnd();

    glColor3f(0.9,0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(870-bt,530);
    glVertex2f(965-bt,540);
    glVertex2f(965-bt,605);
    glVertex2f(880-bt,600);

    glEnd();

///boat2

    glColor3f(0.1,0.2, 0.2);
    glBegin(GL_POLYGON);
    glVertex2f(580,300);
    glVertex2f(645,250);
    glVertex2f(795,250);
    glVertex2f(860,300);
    glVertex2f(795,310);
    glVertex2f(645,310);

    glEnd();

    glColor3f(1.0,0.9, 0.9);
    glBegin(GL_POLYGON);
    glVertex2f(580,300);
    glVertex2f(645,280);
    glVertex2f(795,280);
    glVertex2f(860,300);
    glVertex2f(795,307);
    glVertex2f(645,307);

    glEnd();

    glColor3f(0.1,0.2, 0.2);
    glBegin(GL_POLYGON);
    glVertex2f(785,250);
    glVertex2f(795,250);
    glVertex2f(795,310);
    glVertex2f(785,310);

    glEnd();

    glColor3f(0.1,0.2, 0.2);
    glBegin(GL_POLYGON);
    glVertex2f(715,250);
    glVertex2f(725,250);
    glVertex2f(725,310);
    glVertex2f(715,310);

    glEnd();

    glColor3f(0.1,0.2, 0.2);
    glBegin(GL_POLYGON);
    glVertex2f(645,250);
    glVertex2f(655,250);
    glVertex2f(655,310);
    glVertex2f(645,310);

    glEnd();

    //stick
    glColor3f(0.4,0.0, 4.0);
    glBegin(GL_POLYGON);
    glVertex2f(512,270);
    glVertex2f(520,270);

    glVertex2f(580,300);
    glVertex2f(587,295);

    glEnd();

    glColor3f(0.6,0.6, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(510,220);
    glVertex2f(520,220);
    glVertex2f(520,280);
    glVertex2f(510,280);

    glEnd();



///tree

    glColor3f(0.6,0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(100,60);
    glVertex2f(170,60);
    glVertex2f(170,300);
    glVertex2f(100,300);

    glEnd();
    //root
    glColor3f(0.6,0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(60,40);
    glVertex2f(100,60);
    glVertex2f(170,60);

    glEnd();

    glColor3f(0.6,0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(100,60);
    glVertex2f(200,35);
    glVertex2f(170,60);

    glEnd();

    glColor3f(0.6,0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(100,60);
    glVertex2f(130,30);
    glVertex2f(170,60);

    glEnd();

    //upper
    glColor3f(0.6,0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(100,300);
    glVertex2f(120,300);
    glVertex2f(80,330);
    glVertex2f(70,320);

    glEnd();

    glColor3f(0.6,0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(125,300);
    glVertex2f(145,300);
    glVertex2f(145,340);
    glVertex2f(125,340);

    glEnd();

    glColor3f(0.6,0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(150,300);
    glVertex2f(170,300);
    glVertex2f(190,330);
    glVertex2f(180,340);

    glEnd();

    glColor3f(0.0,0.75,0.0);
    circle(40,30,200,330);

    glColor3f(0.0,0.75,0.0);
    circle(40,30,220,360);

    glColor3f(0.0,0.75,0.0);
    circle(40,30,250,380);

    glColor3f(0.0,0.75,0.0);
    circle(60,30,135,350);

    glColor3f(0.0,0.75,0.0);
    circle(50,50,50,410);

    glColor3f(0.0,0.75,0.0);
    circle(80,90,120,410);

    glColor3f(0.0,0.75,0.0);
    circle(40,50,190,450);

    glColor3f(0.0,0.75,0.0);
    circle(50,50,230,410);

    glColor3f(0.0,0.75,0.0);
    circle(30,30,40,360);

    glColor3f(0.0,0.75,0.0);
    circle(40,30,70,330);

    glColor3f(0.0,0.75,0.0);
    circle(40,30,20,380);

///grass1

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(910,100);
    glVertex2f(930,100);
    glVertex2f(870,130);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(910,100);
    glVertex2f(930,100);
    glVertex2f(960,140);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(910,100);
    glVertex2f(930,100);
    glVertex2f(935,140);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(910,100);
    glVertex2f(925,100);
    glVertex2f(915,130);

    glEnd();

///grass2

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(710,130);
    glVertex2f(730,130);
    glVertex2f(670,150);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(710,130);
    glVertex2f(730,130);
    glVertex2f(760,155);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(710,130);
    glVertex2f(730,130);
    glVertex2f(735,150);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(710,130);
    glVertex2f(725,130);
    glVertex2f(715,160);

    glEnd();

///grass3

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(360,320);
    glVertex2f(380,320);
    glVertex2f(330,360);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(360,320);
    glVertex2f(380,320);
    glVertex2f(410,350);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(360,320);
    glVertex2f(380,320);
    glVertex2f(435,350);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(360,320);
    glVertex2f(375,320);
    glVertex2f(365,350);

    glEnd();


///grass4

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(550,180);
    glVertex2f(570,180);
    glVertex2f(510,200);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(550,180);
    glVertex2f(570,180);
    glVertex2f(530,205);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(550,180);
    glVertex2f(570,180);
    glVertex2f(555,200);

    glEnd();

    glColor3f(0.2,1.0, 0.36);
    glBegin(GL_POLYGON);
    glVertex2f(550,180);
    glVertex2f(565,180);
    glVertex2f(575,210);

    glEnd();



/// /// ///

    glPushMatrix();
    glTranslatef(tx,ty,0);

///ektara

    //up
    glColor3f(0.8,0.4, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(370,250);
    glVertex2f(383,250);
    glVertex2f(383,280);
    glVertex2f(370,280);

    glEnd();

    glColor3f(0.8,0.4, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(383,265);
    glVertex2f(390,265);
    glVertex2f(390,270);
    glVertex2f(383,270);

    glEnd();

    glColor3f(0.75,0.4, 0.0);
    circle(4,4,393,268);

    //down
    glColor3f(0.8,0.4, 0.0);
    circle(10,20,354,140);

    glColor3f(0.8,0.4, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(353,120);
    glVertex2f(403,120);
    glVertex2f(403,160);
    glVertex2f(353,160);

    glEnd();

    glColor3f(0.8,0.4, 0.0);
    circle(10,20,404,140);

    //string
    glColor3f(0.8,0.4, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(352,160);
    glVertex2f(355,160);
    glVertex2f(373,250);
    glVertex2f(370,250);

    glEnd();


    glColor3f(0.8,0.9, 0.9);
    glBegin(GL_LINES);
    glVertex2f(377,250);
    glVertex2f(377,160);

    glEnd();

    glColor3f(0.8,0.4, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(400,160);
    glVertex2f(403,160);
    glVertex2f(383,250);
    glVertex2f(380,250);

    glEnd();


///Man

    //head
    glColor3f(1.0,0.8, 0.6);
    circle(35,30,300,270);

    //hair
    glColor3f(0.0,0.0, 0.0);
    glBegin(GL_POLYGON);

    glVertex2f(300,255);
    glVertex2f(308,301);
    glVertex2f(290,300);
    glVertex2f(282,298);
    glVertex2f(264,280);
    glVertex2f(258,250);
    glEnd();

    //eye
    glColor3f(1.0,1.0, 1.0);
    circle(5,5,320,280);
    glColor3f(0.0,0.0, 0.0);
    circle(1,1,321,280);

    //nose
    glColor3f(1.0,0.8, 0.6);
    glBegin(GL_POLYGON);

    glVertex2f(330,265);
    glVertex2f(343,265);
    glVertex2f(330,280);
    glEnd();

    //nose
    glColor3f(0.4,0.5, 0.6);
    glBegin(GL_POLYGON);

    glVertex2f(312,252);
    glVertex2f(328,250);
    glVertex2f(332,258);
    glEnd();

    //body
    glColor3f(0.4,0.4, 0.4);
    circle(43,70,300,170);

    //lungi
    glColor3f(0.8,1.0, 1.0);
    glBegin(GL_POLYGON);

    glVertex2f(265,35);
    glVertex2f(335,35);
    glVertex2f(335,133);
    glVertex2f(265,133);

    glEnd();

    glColor3f(0.0,0.0, 0.0);
    glBegin(GL_POLYGON);

    glVertex2f(285,35);
    glVertex2f(288,35);
    glVertex2f(288,133);
    glVertex2f(285,133);

    glEnd();

    glColor3f(0.0,0.0, 0.0);
    glBegin(GL_POLYGON);

    glVertex2f(315,35);
    glVertex2f(318,35);
    glVertex2f(318,133);
    glVertex2f(315,133);

    glEnd();
    glColor3f(0.0,0.0, 0.0);
    glBegin(GL_POLYGON);

    glVertex2f(265,60);
    glVertex2f(335,60);
    glVertex2f(335,63);
    glVertex2f(265,63);

    glEnd();

    glColor3f(0.0,0.0, 0.0);
    glBegin(GL_POLYGON);

    glVertex2f(265,100);
    glVertex2f(335,100);
    glVertex2f(335,103);
    glVertex2f(265,103);

    glEnd();

    //leg1
    glColor3f(1.0,0.8, 0.6);
    glBegin(GL_POLYGON);

    glVertex2f(285,0);
    glVertex2f(300,0);
    glVertex2f(300,35);
    glVertex2f(285,35);

    glEnd();

    //leg2
    glColor3f(1.0,0.8, 0.6);
    glBegin(GL_POLYGON);

    glVertex2f(310,0);
    glVertex2f(325,0);
    glVertex2f(325,35);
    glVertex2f(310,35);

    glEnd();

    //hand
    glColor3f(1.0,0.8, 0.6);
    glBegin(GL_POLYGON);

    glVertex2f(295,170);
    glVertex2f(310,170);
    glVertex2f(310,205);
    glVertex2f(295,205);

    glEnd();

    glColor3f(1.0,0.8, 0.6);
    glBegin(GL_POLYGON);

    glVertex2f(295,170);
    glVertex2f(310,170);
    glVertex2f(360,195);
    glVertex2f(360,210);

    glEnd();

    //finger
    if(cnt==0)
    {
        glColor3f(0.9,0.9, 0.9);
        glBegin(GL_POLYGON);

        glVertex2f(360,195);
        glVertex2f(380,220);
        glVertex2f(360,210);

        glEnd();
    }
    else
    {
        glColor3f(0.9,0.9, 0.9);
        glBegin(GL_POLYGON);

        glVertex2f(360,195);
        glVertex2f(370,220);
        glVertex2f(360,210);

        glEnd();
    }

    glColor3f(0.85,0.9, 0.6);
    glBegin(GL_POLYGON);

    glVertex2f(360,195);
    glVertex2f(374,202);
    glVertex2f(360,210);

    glEnd();

    glColor3f(0.85,0.9, 0.6);
    glBegin(GL_POLYGON);

    glVertex2f(360,195);
    glVertex2f(374,209);
    glVertex2f(360,210);

    glEnd();


    glPopMatrix();

/// /// ///

    glFlush();
}

void idle()
{
    if(cnt==0)
    {
        cnt=1;
    }
    else
    {
        cnt=0;
    }
    if(cld<=1100)
    {
        cld+=0.07;
    }
    else
    {
        cld=-380;
    }

    if(brd<=1100)
    {
        brd+=0.1;
    }

    if(bt<=600)
    {
        bt+=0.06;
    }

    if(sn<=550)
    {
        sn+=0.02;
    }

    glutPostRedisplay();
}


void spe_key(int key, int x, int y)
{

    switch (key)
    {

    case GLUT_KEY_LEFT:
        tx -=5;
        glutPostRedisplay();
        break;


    case GLUT_KEY_RIGHT:
        tx +=5;

        glutPostRedisplay();
        break;

    case GLUT_KEY_DOWN:
        // ty -=5;
        //glutPostRedisplay();
        break;


    case GLUT_KEY_UP:
        //ty +=5;
        //glutPostRedisplay();
        break;

    default:
        break;
    }
}


void init(void)
{
    //background color
    glClearColor(1.0,1.0,1.0,0.0); //GLfloat red,green,blue,alpha initial value 0 alpha values used by glclear to clear the color buffers


    glMatrixMode(GL_PROJECTION);  // To specify which matrix is the current matrix & projection applies subsequent matrix to projecton matrix stack
    glLoadIdentity();

    //glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
    gluOrtho2D(0.0,1100.0,0.0,800.0); // Orthographic representation; multiply the current matrix by an orthographic matrix 2D= left, right,bottom,top equivalent near=-1,far=1
}



int main()
{
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);

    glutInitWindowPosition(100,110);

    glutInitWindowSize(1100,800);

    glutCreateWindow("Ektara Playing");

    init();

    glutDisplayFunc(Display);

    glutIdleFunc(idle);

    glutSpecialFunc(spe_key);

    PlaySound("PlayingEktara.wav",NULL,SND_ASYNC);

    glutMainLoop();
    return 0;
}

